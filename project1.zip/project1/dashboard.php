<?php

?>
<html id="productBackground">
<head>
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>Bookstore Products</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="css/home.css">

</head>
<body>
	<div class="page-heading products-heading header-text">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="text-content">
             <h2> <a href="addProduct.php" style="color:rgba(16,31,109);"> Add product </a> </h2> <br/> <br/>
			  <h2> <a href="viewOrders.php" style="color:rgba(16,31,109);"> View Orders </a> </h2>
            </div>
          </div>
        </div>
      </div>
    </div>
	
</body>
</html>